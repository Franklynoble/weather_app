﻿var objImage1 = { url: "/images/1.jpg", imageName: "1.JPG", imageLocation: "Thailand", takenOn: "18/10/2012" };
var objImage2 = { url: "/images/2.jpg", imageName: "2.JPG", imageLocation: "Australia", takenOn: "21/10/2012" };
var objImage3 = { url: "/images/3.jpg", imageName: "3.JPG", imageLocation: "Nepal", takenOn: "23/10/2012" };
var objImage4 = { url: "/images/4.jpg", imageName: "4.JPG", imageLocation: "Europe", takenOn: "28/10/2012" };
var objImage5 = { url: "/images/5.jpg", imageName: "5.JPG", imageLocation: "America", takenOn: "12/3/2013" };
var objImage6 = { url: "/images/6.jpg", imageName: "6.JPG", imageLocation: "Singapore", takenOn: "28/3/2013" };

(function () {
    "use strict";

    WinJS.UI.Pages.define("/pages/home/home.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {
            var image1 = document.getElementById("displayImage1");
            image1.addEventListener("click", this.imageClickHandler1, false);
            var image2 = document.getElementById("displayImage2");
            image2.addEventListener("click", this.imageClickHandler2, false);
            var image3 = document.getElementById("displayImage3");
            image3.addEventListener("click", this.imageClickHandler3, false);
            var image4 = document.getElementById("displayImage4");
            image4.addEventListener("click", this.imageClickHandler4, false);
            var image5 = document.getElementById("displayImage5");
            image5.addEventListener("click", this.imageClickHandler5, false);
            var image6 = document.getElementById("displayImage6");
            image6.addEventListener("click", this.imageClickHandler6, false);
        },
        imageClickHandler1: function (eventInfo) {
            WinJS.Navigation.navigate("/pages/description/description.html", objImage1);
        },
        imageClickHandler2: function (eventInfo) {
            WinJS.Navigation.navigate("/pages/description/description.html", objImage2);
        },

        imageClickHandler3: function (eventInfo) {
            WinJS.Navigation.navigate("/pages/description/description.html", objImage3);
        },

        imageClickHandler4: function (eventInfo) {
            WinJS.Navigation.navigate("/pages/description/description.html", objImage4);
        },

        imageClickHandler5: function (eventInfo) {
            WinJS.Navigation.navigate("/pages/description/description.html", objImage5);
        },
        imageClickHandler6: function (eventInfo) {
            WinJS.Navigation.navigate("/pages/description/description.html", objImage6);
        }
    });
})();
