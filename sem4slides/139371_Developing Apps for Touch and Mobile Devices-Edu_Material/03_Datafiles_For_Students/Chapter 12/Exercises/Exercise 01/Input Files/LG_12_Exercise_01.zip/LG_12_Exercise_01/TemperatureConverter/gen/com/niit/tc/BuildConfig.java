/** Automatically generated file. DO NOT MODIFY */
package com.niit.tc;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}