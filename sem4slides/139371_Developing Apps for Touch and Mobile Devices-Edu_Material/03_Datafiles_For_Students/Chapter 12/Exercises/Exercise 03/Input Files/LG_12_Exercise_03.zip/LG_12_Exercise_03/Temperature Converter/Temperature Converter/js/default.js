﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
    "use strict";

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;

    app.onactivated = function (args) {
        if (args.detail.kind === activation.ActivationKind.launch) {
            if (args.detail.previousExecutionState !== activation.ApplicationExecutionState.terminated) {
            } else {
            }
            args.setPromise(WinJS.UI.processAll());
            document.getElementById('btn').addEventListener('click', onClick, false);
        }
    };

    function onClick() {
        var inu = inum.value;
        var result;
        var type = typ.value;
        if (inu.length == 0) {
            var messageDialog = new Windows.UI.Popups.MessageDialog("Please enter a valid number.", "ERROR");
            messageDialog.showAsync();
        } else {
            if (type == 0) {
                result = ((inu * 9) / 5) + 32;
                var msg = new Windows.UI.Popups.MessageDialog(result + " Fahrenheit", "Celsius to Fahrenheit");
                msg.showAsync();
            } else if (type == 1) {
                result = ((inu - 32) * 5 / 9);
                var msg1 = new Windows.UI.Popups.MessageDialog(result + " Celsius", "Fahrenheit to Celsius");
                msg1.showAsync();
            }
        }
    }

    app.oncheckpoint = function (args) {
    };

    app.start();
})();
