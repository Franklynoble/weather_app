﻿// http://go.microsoft.com/fwlink/?LinkID=290993&clcid=0x409
var MyEventDiaryClient = new WindowsAzure.MobileServiceClient(
                "https://myeventdiary.azure-mobile.net/",
                "saSgjFzaksanqhPSUwmlUiglZqZlff25");