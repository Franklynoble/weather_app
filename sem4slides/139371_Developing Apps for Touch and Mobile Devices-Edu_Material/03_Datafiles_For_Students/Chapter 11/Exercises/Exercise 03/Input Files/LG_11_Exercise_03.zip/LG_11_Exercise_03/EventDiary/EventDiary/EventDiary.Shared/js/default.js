﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkID=392286
(function () {
    "use strict";

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;

    app.onactivated = function (args) {
        if (args.detail.kind === activation.ActivationKind.launch) {
            if (args.detail.previousExecutionState !== activation.ApplicationExecutionState.terminated) {
                // TODO: This application has been newly launched. Initialize
                // your application here.
            } else {
                // TODO: This application has been reactivated from suspension.
                // Restore application state here.
            }
            args.setPromise(WinJS.UI.processAll());

            // Defined the event list used for data binding.
            var eventItems = new WinJS.Binding.List();
            //Retrieve the reference of the Event table.
            var eventTable = MyEventDiaryClient.getTable('Event');
            //Insert data into the Event table.
            var insertEvent = function (eventItem) {
                if (tbTitle.value != "" && tbLocation != "" && taDescription.value != ""){
                    eventTable.insert(eventItem).done(function (eventItem) {
                        eventItems.push(eventItem);
                        tbTitle.value = "";
                        var date = new Date();
                        dtpickerDate.winControl.current = date;
                        tbLocation.value = "";
                        taDescription.value = "";
                    });
                }
                else {
                    var msg = new Windows.UI.Popups.MessageDialog("Fields cannot be left blank.");
                    msg.showAsync();
                    return;
                }
            };

            bttnAdd.addEventListener("click", function () {
                insertEvent({
                    title: tbTitle.value,
                    date: dtpickerDate.winControl.current.toDateString(),
                    location: tbLocation.value,
                    description: taDescription.value
                });
            });
            var refreshEventItems = function () {
                // This code refreshes the entries in the list by querying the Event table;
               eventTable.read().done(function (results) {
                    eventItems = new WinJS.Binding.List(results);
                    listItems.winControl.itemDataSource = eventItems.dataSource;
                    tbTitle.value = "";
                    var date = new Date();
                    dtpickerDate.winControl.current = date;
                    tbLocation.value = "";
                    taDescription.value = "";
                });
            };
            refreshEventItems();

            var eventTitle = "";
            var listViewControl = document.querySelector("#listItems").winControl;
            listViewControl.oniteminvoked = function (event) {
                event.detail.itemPromise.then(function (invokedItem) {
                    eventTitle = invokedItem.data.title;
                    tbTitle.value = invokedItem.data.title;
                    dtpickerDate.winControl.current = invokedItem.data.date;
                    tbLocation.value = invokedItem.data.location;
                    taDescription.value = invokedItem.data.description;
                }).done();
            };
            var updateEventItem = function () {
                if (eventTitle != "") {
                    eventTable.where({ Title: eventTitle }).read().done(
                function (results) {
                    if (results != null) {
                        eventTable.update({ id: results[0].id, title: tbTitle.value, date: dtpickerDate.winControl.current.toDateString(), location: tbLocation.value, description: taDescription.value }).done(
                            function () {
                                refreshEventItems();
                            }
                            );
                    }

                });
                }
                else
                {
                    var msg = new Windows.UI.Popups.MessageDialog("Please select an event to update.");
                    msg.showAsync();
                    return;
                }

            };
            bttnUpdate.addEventListener("click", function () {
                updateEventItem();
            });

            var deleteEventItem = function (eventItem) {
                if (eventTitle != "") {
                    eventTable.where({ Title: eventTitle }).read().done(
                    function (results) {
                        if (results !== null) {
                            eventTable.del({ id: results[0].id }).done(function () { refreshEventItems() });
                        }
                    });
                }
                else
                {
                    var msg = new Windows.UI.Popups.MessageDialog("Please select an event to delete.");
                    msg.showAsync();
                    return;
                }
            };
            bttnDelete.addEventListener("click", function () {
                deleteEventItem();
            });

            var searchEventItems = function () {
                if (tbSearchText.value != "") {
                    eventTable.where({ title: tbSearchText.value }).read().done(function (results) {
                        eventItems = new WinJS.Binding.List(results);
                        listItems.winControl.itemDataSource = eventItems.dataSource;
                    });
                }
                else {
                    var msg = new Windows.UI.Popups.MessageDialog("Please specify the title of the event to search.");
                    msg.showAsync();
                    return;
                }
            };
            bttnSearch.addEventListener("click", function () {
                searchEventItems();
            });



        }
    };

    app.oncheckpoint = function (args) {
        // TODO: This application is about to be suspended. Save any state
        // that needs to persist across suspensions here. You might use the
        // WinJS.Application.sessionState object, which is automatically
        // saved and restored across suspension. If you need to complete an
        // asynchronous operation before your application is suspended, call
        // args.setPromise().
    };

    app.start();
})();