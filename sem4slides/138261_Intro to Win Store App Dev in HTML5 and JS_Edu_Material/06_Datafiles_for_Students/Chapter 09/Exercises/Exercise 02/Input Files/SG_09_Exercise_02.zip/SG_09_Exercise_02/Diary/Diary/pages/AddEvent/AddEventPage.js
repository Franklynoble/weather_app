﻿
// For an introduction to the Page Control template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232511
(function () {
    "use strict";
    var userName;
    WinJS.UI.Pages.define("/pages/AddEvent/AddEventPage.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {
            // TODO: Initialize the page here.
            bttnAdd.onclick = this.bttnAdd_Click;
            userName = options;
            tbTitle.onkeypress = function (args) { return (tbTitle.value.length < 20); };
            taDescription.onkeypress = function (args) { return (taDescription.textContent.length < 100); };
            tbLocation.onkeypress = function (args) { return (tbLocation.value.length < 20); };
        },
        bttnAdd_Click: function (args) {
            if (tbTitle.value == "" || taDescription.textContent == "" || tbLocation.value == "") {
                var msg = new Windows.UI.Popups.MessageDialog("Fields cannot be left blank.");
                msg.showAsync();
                return;
            }
            var newEvent = new nsEvents.Events(tbTitle.value, dtpickerDate.winControl.current.toLocaleDateString(), taDescription.textContent, tbLocation.value);
            nsEventsArray.EventsArray.push(newEvent);
            WinJS.Navigation.navigate("/pages/DetailPage/DetailPage.html", userName);
        },
        unload: function () {
            // TODO: Respond to navigations away from this page.
        },

        updateLayout: function (element, viewState, lastViewState) {
            /// <param name="element" domElement="true" />

            // TODO: Respond to changes in viewState.
        }
    });
})();
