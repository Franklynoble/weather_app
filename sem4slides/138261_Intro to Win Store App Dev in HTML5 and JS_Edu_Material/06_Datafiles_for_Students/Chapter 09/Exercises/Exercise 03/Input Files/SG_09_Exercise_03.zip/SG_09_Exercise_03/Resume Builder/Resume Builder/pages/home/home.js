﻿(function () {
    "use strict";

    WinJS.UI.Pages.define("/pages/home/home.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {
            // TODO: Initialize the page here.
            document.getElementById("submit").addEventListener("click", this.submitclick, false);

            if (WinJS.Application.sessionState.previousExecutionState === Windows.ApplicationModel.Activation.ApplicationExecutionState.terminated && !WinJS.Application.sessionState.sessionRestored) {
                var name = WinJS.Application.sessionState.aname;
                if (name) {
                    document.getElementById("aname").value = name;
                }

                var contact = WinJS.Application.sessionState.acontact;
                if (contact) {
                    document.getElementById("acontact").value = contact;
                }

                var email = WinJS.Application.sessionState.aemail;
                if (email) {
                    document.getElementById("aemail").value = email;
                }
                var website = WinJS.Application.sessionState.awebsite;
                if (website) {
                    document.getElementById("awebsite").selectedIndex = website;
                }

                var objective = WinJS.Application.sessionState.aobj;
                if (objective) {
                    document.getElementById("aobj").value = objective;
                }

                var qualification = WinJS.Application.sessionState.aquali;
                if (qualification) {
                    document.getElementById("aquali").value = qualification;
                }
                var techSkill = WinJS.Application.sessionState.apl;
                if (techSkill) {
                    document.getElementById("apl").value = techSkill;
                }
                var othSkill = WinJS.Application.sessionState.aol;
                if (othSkill) {
                    document.getElementById("aol").value = othSkill;
                }
                var experienceDetails = WinJS.Application.sessionState.aexp;
                if (experienceDetails) {
                    document.getElementById("aexp").value = experienceDetails;
                }
                var workExpyrs = WinJS.Application.sessionState.aworkexpyrs;
                if (workExpyrs) {
                    document.getElementById("aworkexpyrs").value = workExpyrs;
                }

                var workExpmnths = WinJS.Application.sessionState.aworkexpmnths;
                if (workExpmnths) {
                    document.getElementById("aworkexpmnths").value = workExpmnths;
                }

                var dob = WinJS.Application.sessionState.adate;
                if (dob) {
                    adate.winControl.current = new Date(dob);
                }
                
                var nationality = WinJS.Application.sessionState.anationality;
                if (nationality) {
                    document.getElementById("anationality").value = nationality;
                }

                var language = WinJS.Application.sessionState.alang;
                if (language) {
                    document.getElementById("alang").value = language;
                }

                var single = WinJS.Application.sessionState.single;

                if (single == true)
                    document.getElementById("single").checked = true;
                else
                    document.getElementById("married").checked = true;

                var male = WinJS.Application.sessionState.male;

                if (male == true)
                    document.getElementById("male").checked = true;
                else
                    document.getElementById("female").checked = true;

                WinJS.Application.sessionState.sessionRestored = true;

            }





        },

        submitclick: function (e) {
            var object1 = {
                uname: aname.value, ucontact: acontact.value, uemail: aemail.value, uwebsite: awebsite.value,
                uobj: aobj.textContent, uquali: aquali.textContent, upl: apl.value, uol: aol.value, uexp: aexp.textContent, uworkexpyrs: aworkexpyrs.value,
                uworkexpmnths: aworkexpmnths.value, udate: adate.winControl.current, unationality: anationality.value, ustatus: astatus[0].checked,
                ul: alang.value, ugender: agender[0].checked
            };


            if (aname.value == "" || acontact.value == "" || aemail.value == "" || aobj.textContent == "" || aquali.textContent == "" || apl.value == "" || aol.value == "" || aexp.textContent == "" || aworkexpyrs.value == "" || aworkexpmnths.value == "" || anationality.value == "" || alang.value == "") {

                var msg = new Windows.UI.Popups.MessageDialog("Please complete the form!!");
                msg.showAsync();

            }

            else {
                WinJS.Navigation.navigate("/pages/resume/resume.html", object1);
            }
        }

    });
})();