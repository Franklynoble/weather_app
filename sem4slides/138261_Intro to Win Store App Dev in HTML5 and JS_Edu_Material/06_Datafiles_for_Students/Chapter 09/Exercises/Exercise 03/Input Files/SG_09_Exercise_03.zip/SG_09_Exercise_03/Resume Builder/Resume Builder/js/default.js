﻿// For an introduction to the Navigation template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232506
(function () {
    "use strict";

    WinJS.Binding.optimizeBindingReferences = true;

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;
    var nav = WinJS.Navigation;

    app.addEventListener("activated", function (args) {
        WinJS.Application.sessionState.sessionRestored = false;
        if (args.detail.kind === activation.ActivationKind.launch) {
            if (args.detail.previousExecutionState !== activation.ApplicationExecutionState.terminated) {
                // TODO: This application has been newly launched. Initialize
                // your application here.
            } else {
                // TODO: This application has been reactivated from suspension.
                // Restore application state here.
            }

            WinJS.Application.sessionState.previousExecutionState =
              args.detail.previousExecutionState;

            if (app.sessionState.history) {
                nav.history = app.sessionState.history;
            }
            args.setPromise(WinJS.UI.processAll().then(function () {
                if (nav.location) {
                    nav.history.current.initialPlaceholder = true;
                    return nav.navigate(nav.location, nav.state);
                } else {
                    return nav.navigate(Application.navigator.home);
                }
            }));
        }
    });

    app.oncheckpoint = function (args) {
        // TODO: This application is about to be suspended. Save any state
        // that needs to persist across suspensions here. If you need to 
        // complete an asynchronous operation before your application is 
        // suspended, call args.setPromise().
        app.sessionState.history = nav.history;

        if (nav.history.current.location.indexOf("resume.html") == -1) {

            var name = document.getElementById("aname");
            if (name) {
                WinJS.Application.sessionState.aname = name.value;
            }

            var contact = document.getElementById("acontact");
            if (contact) {
                WinJS.Application.sessionState.acontact = contact.value;
            }

            var email = document.getElementById("aemail");
            if (email) {
                WinJS.Application.sessionState.aemail = email.value;
            }


            var website = document.getElementById("awebsite");
            if (website) {
                WinJS.Application.sessionState.awebsite = website.selectedIndex;
            }

            var objective = document.getElementById("aobj");
            if (objective) {
                WinJS.Application.sessionState.aobj = objective.textContent;
            }
            var qualification = document.getElementById("aquali");
            if (qualification) {
                WinJS.Application.sessionState.aquali = qualification.textContent;
            }

            var techSkill = document.getElementById("apl");
            if (techSkill) {
                WinJS.Application.sessionState.apl = techSkill.value;
            }

            var othSkill = document.getElementById("aol");
            if (othSkill) {
                WinJS.Application.sessionState.aol = othSkill.value;
            }

            var experienceDetails = document.getElementById("aexp");
            if (experienceDetails) {
                WinJS.Application.sessionState.aexp = experienceDetails.textContent;
            }

            var workExpyrs = document.getElementById("aworkexpyrs");
            if (workExpyrs) {
                WinJS.Application.sessionState.aworkexpyrs = workExpyrs.value;
            }

            var workExpmnths = document.getElementById("aworkexpmnths");
            if (workExpmnths) {
                WinJS.Application.sessionState.aworkexpmnths = workExpmnths.value;
            }

            var dob = document.getElementById("adate");
            if (dob) {
                WinJS.Application.sessionState.adate = dob.winControl.current.toLocaleDateString();
            }

            var nationality = document.getElementById("anationality");
            if (nationality) {
                WinJS.Application.sessionState.anationality = nationality.value;
            }

            var language = document.getElementById("alang");
            if (language) {
                WinJS.Application.sessionState.alang = language.value;
            }

            var single = document.getElementById("single");
            if (single) {
                WinJS.Application.sessionState.single = single.checked;
            }

            var male = document.getElementById("male");
            if (male) {
                WinJS.Application.sessionState.male = male.checked;
            }



        }




    };

    app.start();
})();
