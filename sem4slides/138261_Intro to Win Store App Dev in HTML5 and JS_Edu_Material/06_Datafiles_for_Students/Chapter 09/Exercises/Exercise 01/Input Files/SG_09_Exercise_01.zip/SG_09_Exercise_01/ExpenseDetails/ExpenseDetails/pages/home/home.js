﻿function bttnAdd_click(eventInfo) {
    if (tbAmount.value == "" || taDescription.textContent == "" || cboxExpenseType.selectedIndex == 0) {

        var strMessage = "Fields cannot be left blank.";
        var msg = new Windows.UI.Popups.MessageDialog(strMessage);
        msg.showAsync();
    }
    else {
        nsExpenseArray.expnsArray.push(new Expense(dtExpense.winControl.current.toLocaleDateString(), cboxExpenseType.value, tbAmount.value, taDescription.textContent));
        var msg = new Windows.UI.Popups.MessageDialog("Expense added successfully.");
        msg.showAsync();
        tbAmount.value = taDescription.textContent = "";
        cboxExpenseType.selectedIndex = 0;
    }

}
function checkKeyStroke(args) {
    if (args.keyCode < 48 || args.keyCode > 57)
        return false;

}
function bttnViewExpense_Click(eventInfo) {
    WinJS.Navigation.navigate("/pages/details/details.html", expenseArray);
}
(function () {
    "use strict";

    WinJS.UI.Pages.define("/pages/home/home.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {
            // TODO: Initialize the page here.
            bttnAdd.onclick = bttnAdd_click;
            tbAmount.onkeypress = checkKeyStroke;
            bttnViewExpense.onclick = bttnViewExpense_Click;
            taDescription.onkeypress = function (args) {
                return (taDescription.value.length < 120);
            }

            if (WinJS.Application.sessionState.previousExecutionState === Windows.ApplicationModel.Activation.ApplicationExecutionState.terminated && !WinJS.Application.sessionState.sessionRestored) {
                {
                    var date = WinJS.Application.sessionState.dtExpense;
                    if (date) {
                        dtExpense.winControl.current = new Date(date);
                    }

                    var expenseType = WinJS.Application.sessionState.cboxExpenseType;
                    if (expenseType) {
                        document.getElementById("cboxExpenseType").selectedIndex = expenseType;
                    }

                    var amount = WinJS.Application.sessionState.tbAmount;
                    if (amount) {
                        document.getElementById("tbAmount").value = amount;
                    }
                    var description = WinJS.Application.sessionState.taDescription;
                    if (description) {
                        document.getElementById("taDescription").textContent = description;
                    }
                    WinJS.Application.sessionState.sessionRestored = true;

                }
            }
        }
    });
})();
