﻿var imageArray = new Array(
"apple.png",
"ball.png",
"car.png",
"dog.png",
"egg.png",
"flower.png",
"glasses.png",
"hat.png",
"icecream.png",
"juice.png",
"keys.png",
"ladder.png",
"moon.png",
"nest.png",
"orange.png",
"pen.png",
"quilt.png",
"rabbit.png",
"shoes.png",
"truck.png",
"umbrella.png",
"vaccuum.png",
"watch.png",
"xylophone.png",
"yoghurt.png",
"zebra.png"

);

(function () {
    "use strict";
    WinJS.Binding.optimizeBindingReferences = true;
    WinJS.UI.Pages.define("/pages/home/home.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {
            // TODO: Initialize the page here.
            for (var i = 0; i <= 26; ++i) {
                var bttn = document.getElementById("bttn" + i);
                if (bttn)
                    bttn.onclick = this.bttn_Click;
            }
            bttnAssessment.onclick = function (args) {
                WinJS.Navigation.navigate("/pages/Assessment/Assessment.html");
            };
        },
        bttn_Click : function (args) {
    var bttnID = this.id;
    var bttnLabel = this.innerText;
    for (var i = 0; i < imageArray.length; i++) {
        if (imageArray[i].charAt(0) == bttnLabel.toLowerCase()) {
            imgLetter.src = "/images/letters/" + imageArray[i];
            var objectName = imageArray[i].replace(".png", "");
            lblWord.innerText = objectName.toUpperCase();
            letterVoice.src = "/sounds/" + objectName.charAt(0) + ".mp3";
            break;
        }
    }
}
    });
})();
