﻿var dataList;
(function () {
    "use strict";

    WinJS.UI.Pages.define("/pages/home/home.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.


        ready: function (element, options) {
            // TODO: Initialize the page here.
            document.getElementById("lstVContactDetails").addEventListener("iteminvoked", this.itemInvoked, false);
            tbContactName.onkeyup = function (args) {
                var filteredList = dataList.createFiltered(function (listItem) {
                    return (listItem.firstname.toUpperCase().indexOf(tbContactName.value.toUpperCase()) >= 0)

                });
                var publicMembers =
      {
          itemList: filteredList
      };
                WinJS.Namespace.define("DataExample", publicMembers);

                lstVContactDetails.winControl.itemDataSource = DataExample.itemList.dataSource;
            };

        },
        itemInvoked: function (eventInfo) {
            eventInfo.detail.itemPromise.then(function (invokedItem) {
                WinJS.Navigation.navigate("/pages/DetailPage/DetailPage.html", invokedItem.data);
            });

        }

    });
    var Person = WinJS.Binding.define({
        firstname: "",
        lastname: "",
        pImg: "",
        mobileNo: "",
        email: "",
    });

    var people = [
           new Person({ firstname: "Bob", lastname: "Patrick", pImg: "ms-appx:///images/1.jpg", mobileNo: "9852224517", email: "bob989@yahoo.com" }),
           new Person({ firstname: "Sally", lastname: "John", pImg: "ms-appx:///images/2.jpg", mobileNo: "9987234121", email: "sally.99@hotmail.com" }),
           new Person({ firstname: "Marry", lastname: "Smith", pImg: "ms-appx:///images/3.jpg", mobileNo: "7867882312", email: "marry_Smith@yahoo.com" }),
           new Person({ firstname: "David", lastname: "Peter", pImg: "ms-appx:///images/4.jpg", mobileNo: "9999881278", email: "peter002@gmail.com" }),
           new Person({ firstname: "Steve", lastname: "Paul", pImg: "ms-appx:///images/5.jpg", mobileNo: "9876564689", email: "steve.paul@yahoo.com" }),
           new Person({ firstname: "Allen", lastname: "Jessie", pImg: "ms-appx:///images/6.jpg", mobileNo: "9544561298", email: "allen1990@yahoo.com" }),
           new Person({ firstname: "Genelia", lastname: "Joseph", pImg: "ms-appx:///images/7.jpg", mobileNo: "9544561298", email: "Gennie@hotmail.com" }),



    ];
    dataList = new WinJS.Binding.List(people);
    dataList.sort(function (person1, person2) {
        return person1.firstname.toUpperCase().localeCompare(person2.firstname.toUpperCase());
    });
    var publicMembers =
       {
           itemList: dataList
       };
    WinJS.Namespace.define("DataExample", publicMembers);
})();
