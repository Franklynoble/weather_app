﻿// For an introduction to the Page Control template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232511
(function () {
    "use strict";

    WinJS.UI.Pages.define("/pages/stories/story.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {
            // TODO: Initialize the page here.
            
            if (WinJS.Application.sessionState.previousExecutionState === Windows.ApplicationModel.Activation.ApplicationExecutionState.terminated && !WinJS.Application.sessionState.sessionRestored) {
                var title = WinJS.Application.sessionState.title;
                if (title) {
                    document.getElementById("title").value = title;

                }

                var story = WinJS.Application.sessionState.story;
                if (story) {
                    document.getElementById("story").textContent = story;

                }
                WinJS.Application.sessionState.sessionRestored = true;
            }
            else {
                document.getElementById("title").value = options.title;
                document.getElementById("story").textContent = options.story;

                var sp = Windows.ApplicationModel.DataTransfer.DataTransferManager.getForCurrentView();
                sp.ondatarequested = function (e) {
                    e.request.data.properties.title = document.getElementById("title").innerText;
                    e.request.data.setText(document.getElementById("story").innerText);
                }
            }
        },

        unload: function () {
            // TODO: Respond to navigations away from this page.
        },

        updateLayout: function (element, viewState, lastViewState) {
            /// <param name="element" domElement="true" />

            // TODO: Respond to changes in viewState.
        }
    });
})();
