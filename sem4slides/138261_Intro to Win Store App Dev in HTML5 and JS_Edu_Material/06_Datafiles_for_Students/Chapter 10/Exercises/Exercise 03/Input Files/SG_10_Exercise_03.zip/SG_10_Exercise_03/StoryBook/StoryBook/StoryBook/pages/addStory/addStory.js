﻿// For an introduction to the Page Control template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232511
(function () {
    "use strict";
    WinJS.UI.Pages.define("/pages/addStory/addStory.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {
            // TODO: Initialize the page here.
            var saveCommand = document.getElementById("cmdSave");
            saveCommand.addEventListener("click", this.saveCommandHandler, false);

            if (WinJS.Application.sessionState.previousExecutionState === Windows.ApplicationModel.Activation.ApplicationExecutionState.terminated && !WinJS.Application.sessionState.sessionRestored) {
                var inputTitle = WinJS.Application.sessionState.inputTitle;
                if (inputTitle) {
                    document.getElementById("inputTitle").value = inputTitle;

                }

                var inputStory = WinJS.Application.sessionState.inputStory;
                if (inputStory) {
                    document.getElementById("inputStory").textContent = inputStory;

                }
                WinJS.Application.sessionState.sessionRestored = true;
            }


        },
        saveCommandHandler: function(eventInfo)
        {
            var title = document.getElementById("inputTitle").value;
            var story = document.getElementById("inputStory").value;
            if (title=="" || story=="") {
                var msg = new Windows.UI.Popups.MessageDialog("Please enter the story details!");
                msg.showAsync();
            }
            else {

                if (!Windows.Storage.ApplicationData.current.localSettings.values["LastIndex"]) {
                    Windows.Storage.ApplicationData.current.localSettings.values["LastIndex"] = 0;
                }

                var lastIndex = Windows.Storage.ApplicationData.current.localSettings.values["LastIndex"];
                var composite = new Windows.Storage.ApplicationDataCompositeValue();
                composite["Story"] = story;
                composite["Title"] = title;
                Windows.Storage.ApplicationData.current.localSettings.values[lastIndex] = composite;
                Windows.Storage.ApplicationData.current.localSettings.values["LastIndex"] = lastIndex + 1;
                WinJS.Navigation.navigate("/pages/home/home.html");
                           
            }
        },
        unload: function () {
            // TODO: Respond to navigations away from this page.
        },

        updateLayout: function (element, viewState, lastViewState) {
            /// <param name="element" domElement="true" />

            // TODO: Respond to changes in viewState.
        }
    });
   
})();
