﻿(function () {
    "use strict";
    WinJS.Binding.optimizeBindingReferences = true;
    var StoryCollection = WinJS.Binding.define({
        title: "",
        story: ""
    });
    var stories = new Array();

    WinJS.UI.Pages.define("/pages/home/home.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.

        ready: function (element, options) {
            // TODO: Initialize the page here.            
            while (stories.length > 0)
                stories.pop();
            var addCommand = document.getElementById("cmdAdd");
            addCommand.addEventListener("click", this.addCommandClickHandler, false);
            document.getElementById("storieslst").addEventListener("iteminvoked", this.itemInvoked, false);
          
            for(var i = 0; i < Windows.Storage.ApplicationData.current.localSettings.values["LastIndex"]; i++) {
                
                        var stry = new StoryCollection();
                        var tempStory = Windows.Storage.ApplicationData.current.localSettings.values[i];
                        stry.title = tempStory.Title;
                        stry.story = tempStory.Story; 
                        stories.push(stry);
                        var dataList = new WinJS.Binding.List(stories);
                        var publicMembers =
                           {
                               itemList: dataList,
                               addedStories: stories
                           };
                        WinJS.Namespace.define("DataExample", publicMembers);
                        storieslst.winControl.itemDataSource = DataExample.itemList.dataSource;
                    }
                    if (stories.length === 0)
                        noStory.style.visibility = "visible";
                    else
                        noStory.style.visibility = "hidden";

                    WinJS.Application.sessionState.sessionRestored = true;
                    bttnStoryDetails.onclick = function () {
                        if (stories.length!=0) {
                            var currentState = Windows.UI.ViewManagement.ApplicationView.value;
                            if (currentState === Windows.UI.ViewManagement.ApplicationViewState.snapped && !Windows.UI.ViewManagement.ApplicationView.tryUnsnap()) {
                                return;
                            }

                            var savePicker = new Windows.Storage.Pickers.FileSavePicker();
                            savePicker.suggestedStartLocation = Windows.Storage.Pickers.PickerLocationId.documentsLibrary;
                            savePicker.fileTypeChoices.insert("Plain Text File", [".TXT"]);
                            savePicker.suggestedFileName = "StoryDetailsBackup";
                            var storyDetailsBackup = new Array();
                            //for (var i = 0; i < arr.length; i++)
                            for (var i = 0; i < Windows.Storage.ApplicationData.current.localSettings.values["LastIndex"]; i++) {
                                var stry = new StoryCollection();

                                var tempStory = Windows.Storage.ApplicationData.current.localSettings.values[i];
                                stry.title = tempStory.Title;
                                stry.story = tempStory.Story;
                                // stories.push(stry);
                                storyDetailsBackup.push("Title: " + stry.title);
                                storyDetailsBackup.push("Description: " + stry.story.replace(/\n/gi, " "));
                                storyDetailsBackup.push("");
                                storyDetailsBackup.push("********************************************************************");
                                storyDetailsBackup.push("");

                            }

                            savePicker.pickSaveFileAsync().then(function (file) {
                                if (file) {
                                    Windows.Storage.FileIO.writeLinesAsync(file, storyDetailsBackup).done(function () {
                                        var msg = Windows.UI.Popups.MessageDialog("Story details exported successfully.");
                                        msg.showAsync();
                                    });

                                }

                            });
                        }
                        else {
                            var msg = Windows.UI.Popups.MessageDialog("Please add a story!!");
                            msg.showAsync();

                        }
                        };
                    

           },
        addCommandClickHandler: function (eventInfo) {
     
            WinJS.Navigation.navigate("/pages/addStory/addStory.html");
        },
        itemInvoked: function (eventInfo) {
            eventInfo.detail.itemPromise.then(function (invokedItem) {
                WinJS.Navigation.navigate("/pages/stories/story.html", invokedItem.data);
            });

        }
    });


})();
