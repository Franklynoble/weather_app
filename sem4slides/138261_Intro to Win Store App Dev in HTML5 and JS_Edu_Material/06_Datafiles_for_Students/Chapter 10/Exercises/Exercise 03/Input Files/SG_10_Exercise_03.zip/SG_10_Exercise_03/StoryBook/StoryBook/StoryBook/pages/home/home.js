﻿(function () {
    "use strict";
    WinJS.Binding.optimizeBindingReferences = true;
    var StoryCollection = WinJS.Binding.define({
        title: "",
        story: ""
    });
    var stories = new Array();

    WinJS.UI.Pages.define("/pages/home/home.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.

        ready: function (element, options) {
            // TODO: Initialize the page here.            
            while (stories.length > 0)
                stories.pop();
            var addCommand = document.getElementById("cmdAdd");
            addCommand.addEventListener("click", this.addCommandClickHandler, false);
            document.getElementById("storieslst").addEventListener("iteminvoked", this.itemInvoked, false);
          
            for(var i = 0; i < Windows.Storage.ApplicationData.current.localSettings.values["LastIndex"]; i++) {
                
                        var stry = new StoryCollection();
                        var tempStory = Windows.Storage.ApplicationData.current.localSettings.values[i];
                        stry.title = tempStory.Title;
                        stry.story = tempStory.Story; 
                        stories.push(stry);
                        var dataList = new WinJS.Binding.List(stories);
                        var publicMembers =
                           {
                               itemList: dataList,
                               addedStories: stories
                           };
                        WinJS.Namespace.define("DataExample", publicMembers);
                        storieslst.winControl.itemDataSource = DataExample.itemList.dataSource;
                    }
                    if (stories.length === 0)
                        noStory.style.visibility = "visible";
                    else
                        noStory.style.visibility = "hidden";
           },
        addCommandClickHandler: function (eventInfo) {
            WinJS.Navigation.navigate("/pages/addStory/addStory.html");
        },
        itemInvoked: function (eventInfo) {
            eventInfo.detail.itemPromise.then(function (invokedItem) {
                WinJS.Navigation.navigate("/pages/stories/story.html", invokedItem.data);
            });

        }
    });


})();
