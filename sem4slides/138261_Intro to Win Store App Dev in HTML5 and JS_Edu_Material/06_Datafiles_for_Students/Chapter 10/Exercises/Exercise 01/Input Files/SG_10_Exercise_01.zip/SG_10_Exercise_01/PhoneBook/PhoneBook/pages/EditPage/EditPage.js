﻿var index;
// For an introduction to the Page Control template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232511
(function () {
    "use strict";

    WinJS.UI.Pages.define("/pages/EditPage/EditPage.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {
            // TODO: Initialize the page here.
            WinJS.Application.sessionState.index = options;

            if (WinJS.Application.sessionState.previousExecutionState === Windows.ApplicationModel.Activation.ApplicationExecutionState.terminated && !WinJS.Application.sessionState.sessionRestored)
            {
                {
                    var firstName = WinJS.Application.sessionState.firstName;
                    if (firstName) {
                        document.getElementById("firstName").value = firstName;
                    }

                    var lastName = WinJS.Application.sessionState.lastName;
                    if (lastName) {
                        document.getElementById("lastName").value = lastName;
                    }

                    var img = WinJS.Application.sessionState.img;
                    if (img) {
                        document.getElementById("img").src = img;
                    }
                    var phoneNo = WinJS.Application.sessionState.phoneNo;
                    if (phoneNo) {
                        document.getElementById("phoneNo").value = phoneNo;
                    }
                    
                    var emailID = WinJS.Application.sessionState.emailID;
                    if (emailID) {
                        document.getElementById("emailID").value = emailID;
                    }
                    WinJS.Application.sessionState.sessionRestored = true;

                }
            }

            else {

                index = options;
                document.getElementById("firstName").innerText = peopleData.peopleArray[index].firstname;
                document.getElementById("lastName").innerText = peopleData.peopleArray[index].lastname;
                document.getElementById("img").src = peopleData.peopleArray[index].pImg;
                document.getElementById("phoneNo").innerText = peopleData.peopleArray[index].mobileNo;
                document.getElementById("emailID").innerText = peopleData.peopleArray[index].email;

            }
            document.getElementById("update").addEventListener("click", this.update_event, false);

        },

        unload: function () {
            // TODO: Respond to navigations away from this page.
        },

        update_event : function(e)
        {
            
            if (index == undefined)
                index = WinJS.Application.sessionState.index;
            peopleData.peopleArray[index].firstname = firstName.value;
            peopleData.peopleArray[index].lastname = lastName.value;
            peopleData.peopleArray[index].mobileNo = phoneNo.value;
            peopleData.peopleArray[index].email = emailID.value;

            var localSettings = Windows.Storage.ApplicationData.current.localSettings;
            localSettings.values.clear();
            localSettings.values["appDataCreated"] = false;
            for (var i = 0; i < peopleData.peopleArray.length; i++) {
                var composite = new Windows.Storage.ApplicationDataCompositeValue();
                composite["firstname"] = peopleData.peopleArray[i].firstname;
                composite["lastname"] = peopleData.peopleArray[i].lastname;
                composite["pImg"] = peopleData.peopleArray[i].pImg;
                composite["mobileNo"] = peopleData.peopleArray[i].mobileNo;
                composite["email"] = peopleData.peopleArray[i].email;

                Windows.Storage.ApplicationData.current.localSettings.values[i] = composite;


            }

            Windows.Storage.ApplicationData.current.localSettings.values["LastIndex"] = peopleData.peopleArray.length;

            localSettings.values["appDataCreated"] = true;


            var msg = Windows.UI.Popups.MessageDialog("Contact details updated.");
            msg.showAsync().done(function () {
                WinJS.Navigation.navigate('/pages/home/home.html');
            });

        },
         
        updateLayout: function (element, viewState, lastViewState) {
           

            // TODO: Respond to changes in viewState.
        }
    });
})();
