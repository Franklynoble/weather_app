﻿var contactsList;
// For an introduction to the Page Control template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232511
(function () {
    "use strict";

    WinJS.UI.Pages.define("/pages/DetailPage/DetailPage.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {

            if (options != undefined && options.firstname != undefined) {
                document.getElementById("firstName").innerText = options.firstname;
                document.getElementById("lastName").innerText = options.lastname;
                document.getElementById("img").src = options.pImg;
                document.getElementById("phoneNo").innerText = options.mobileNo;
                document.getElementById("emailID").innerText = options.email;

            }
            else {
                var firstName = WinJS.Application.sessionState.firstName;
                var lastName = WinJS.Application.sessionState.lastName;
                var img = WinJS.Application.sessionState.img;
                var phoneNo = WinJS.Application.sessionState.phoneNo;
                var emailID = WinJS.Application.sessionState.emailID;

                // TODO: Initialize the page here.
                if (WinJS.Application.sessionState.previousExecutionState === Windows.ApplicationModel.Activation.ApplicationExecutionState.terminated && !WinJS.Application.sessionState.sessionRestored) {
                    if (firstName) {
                        document.getElementById("firstName").innerText = firstName;
                    }

                    if (lastName) {
                        document.getElementById("lastName").innerText = lastName;
                    }

                    if (img) {
                        document.getElementById("img").src = img;
                    }
                    if (phoneNo) {
                        document.getElementById("phoneNo").innerText = phoneNo;
                    }

                    if (emailID) {
                        document.getElementById("emailID").innerText = emailID;
                    }
                    WinJS.Application.sessionState.sessionRestored = true;

                }
            }

        },

        unload: function () {
            // TODO: Respond to navigations away from this page.
        },

        updateLayout: function (element, viewState, lastViewState) {
            /// <param name="element" domElement="true" />

            // TODO: Respond to changes in viewState.
        }
    });
})();
