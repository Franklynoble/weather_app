﻿//Defining an array of objects
var expensesList;
//Defining a group item list
var groupedItemsList

//Defining a namespace to make data accessible publicly
WinJS.Namespace.define("groupedExpenses",
   {
       groupItemsList: groupedItemsList
   });



// For an introduction to the Page Control template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232511
(function () {
    "use strict";

    WinJS.UI.Pages.define("/pages/details/details.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {
            // TODO: Initialize the page here.


            var arr = new Array();
            for (var i = 0; i < options.length; i++) {

                arr.push(new expense.expenses(options[i].expenseDate, options[i].expenseType, options[i].expenseAmount, options[i].expenseDescription));
            }


            expensesList = new WinJS.Binding.List(arr);

            // Create the groups for the ListView from the item data and the grouping functions
            groupedItemsList = expensesList.createGrouped(function (dataItem) {
                return dataItem.expenseType.toUpperCase();
            }, function (dataItem) {
                return {
                    ExpenseType: dataItem.expenseType.toUpperCase()
                };
            }, function (leftKey, rightKey) {
                return leftKey.toUpperCase().localeCompare(rightKey.toUpperCase());
            });

            //Defining a namespace to make data accessible publicly
            WinJS.Namespace.define("groupedExpenses",
               {
                   groupItemsList: groupedItemsList
               });
            zoomedInListView.winControl.itemDataSource = groupedExpenses.groupItemsList.dataSource;
            zoomedInListView.winControl.groupDataSource = groupedExpenses.groupItemsList.groups.dataSource;
            zoomedOutListView.winControl.itemDataSource = groupedExpenses.groupItemsList.groups.dataSource;
        },

        unload: function () {
            // TODO: Respond to navigations away from this page.
        },

        updateLayout: function (element, viewState, lastViewState) {
            /// <param name="element" domElement="true" />

            // TODO: Respond to changes in viewState.
        }
    });
})();
