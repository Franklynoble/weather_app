﻿var Expense = WinJS.Class.define(function (expenseDate, expenseType, expenseAmount, expenseDescription) {
    this.expenseDate = expenseDate;
    this.expenseType = expenseType;
    this.expenseAmount = expenseAmount;
    this.expenseDescription = expenseDescription;
},
    {
        expenseDate: "", expenseType: "", expenseAmount: 0.0, expenseDescription: ""
    },
    null
   );

WinJS.Namespace.define("expense",
               {
                   expenses: Expense
               });
var expenseArray = new Array();
function bttnAdd_click(eventInfo) {
    if (tbAmount.value == "" || taDescription.textContent == "" || cboxExpenseType.selectedIndex == 0) {

        var strMessage = "Fields cannot be left blank.";
        var msg = new Windows.UI.Popups.MessageDialog(strMessage);
        msg.showAsync();
    }
    else {
        expenseArray.push(new Expense(dtExpense.winControl.current.toLocaleDateString(), cboxExpenseType.value, tbAmount.value, taDescription.textContent));
        var msg = new Windows.UI.Popups.MessageDialog("Expense added successfully.");
        msg.showAsync();
        tbAmount.value = taDescription.textContent = "";
        cboxExpenseType.selectedIndex = 0;
    }

}
function checkKeyStroke(args) {
    if (args.keyCode < 48 || args.keyCode > 57)
        return false;

}
function bttnViewExpense_Click(eventInfo) {
    WinJS.Navigation.navigate("/pages/details/details.html", expenseArray);
}
(function () {
    "use strict";

    WinJS.UI.Pages.define("/pages/home/home.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {
            // TODO: Initialize the page here.
            bttnAdd.onclick = bttnAdd_click;
            tbAmount.onkeypress = checkKeyStroke;
            bttnViewExpense.onclick = bttnViewExpense_Click;
            taDescription.onkeypress = function (args) {
                return (taDescription.value.length < 120);
            }
        }
    });
})();
