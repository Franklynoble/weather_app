﻿

var dataList;
var Person = WinJS.Binding.define({
    firstname: "",
    lastname: "",
    pImg: "",
    mobileNo: "",
    email: "",
});

var info = new Array();


var people = [
       new Person({ firstname: "Bob", lastname: "Patrick", pImg: "ms-appx:///images/1.jpg", mobileNo: "9852224517", email: "bob989@yahoo.com" }),
       new Person({ firstname: "Sally", lastname: "John", pImg: "ms-appx:///images/2.jpg", mobileNo: "9987234121", email: "sally.99@hotmail.com" }),
       new Person({ firstname: "Marry", lastname: "Smith", pImg: "ms-appx:///images/3.jpg", mobileNo: "7867882312", email: "marry_Smith@yahoo.com" }),
       new Person({ firstname: "David", lastname: "Peter", pImg: "ms-appx:///images/4.jpg", mobileNo: "9999881278", email: "peter002@gmail.com" }),
       new Person({ firstname: "Steve", lastname: "Paul", pImg: "ms-appx:///images/5.jpg", mobileNo: "9876564689", email: "steve.paul@yahoo.com" }),
       new Person({ firstname: "Allen", lastname: "Jessie", pImg: "ms-appx:///images/6.jpg", mobileNo: "9544561298", email: "allen1990@yahoo.com" }),
       new Person({ firstname: "Genelia", lastname: "Joseph", pImg: "ms-appx:///images/7.jpg", mobileNo: "9544561298", email: "Gennie@hotmail.com" }),


];
var publicPeopleArray =
{
    peopleArray: people
};
WinJS.Namespace.define("peopleData", publicPeopleArray);

function onEdit(eventInfo) {
    var listView = document.getElementById('lstVContactDetails').winControl;
    var selection = listView.selection.getItems().done(function (items) {

        items.forEach(function (item) {
            for (var i = 0; i < peopleData.peopleArray.length; i++) {
                if (peopleData.peopleArray[i].firstname == item.data.firstname) {
                    WinJS.Navigation.navigate("/pages/EditPage/EditPage.html", i);
                    break;
                }
            }

        });

    });
}


function onDelete() {

    var msg = Windows.UI.Popups.MessageDialog("Are you sure that you want to delete the record?");
    msg.commands.append(new Windows.UI.Popups.UICommand("Yes", function (msg) {

        var listView = document.getElementById('lstVContactDetails').winControl;
        var selection = listView.selection.getItems().done(function (items) {
            items.forEach(function (item) {
                for (var i = 0; i < peopleData.peopleArray.length; i++) {
                    if (peopleData.peopleArray[i].firstname == item.data.firstname) {
                        peopleData.peopleArray.splice(i, 1);
                        break;
                    }
                }



            });

        });
        dataList = new WinJS.Binding.List(people);
        dataList.sort(function (person1, person2) {
            return person1.firstname.toUpperCase().localeCompare(person2.firstname.toUpperCase());
        });
        var publicMembers =
           {
               itemList: dataList
           };
        WinJS.Namespace.define("DataExample", publicMembers);
        lstVContactDetails.winControl.itemDataSource = DataExample.itemList.dataSource;
    }));
    msg.commands.append(new Windows.UI.Popups.UICommand("No", function (msg) {

         
        lstVContactDetails.winControl.itemDataSource = null;
         dataList = new WinJS.Binding.List(people);
         dataList.sort(function (person1, person2) {
         return person1.firstname.toUpperCase().localeCompare(person2.firstname.toUpperCase());
        });
        lstVContactDetails.winControl.itemDataSource = DataExample.itemList.dataSource;
    }));


    msg.showAsync();

}


(function () {
    "use strict";

    WinJS.UI.Pages.define("/pages/home/home.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.


        ready: function (element, options) {
            // TODO: Initialize the page here.

            dataList = new WinJS.Binding.List(people);
            dataList.sort(function (person1, person2) {
                return person1.firstname.toUpperCase().localeCompare(person2.firstname.toUpperCase());
            });
            var publicMembers =
               {
                   itemList: dataList
               };
            WinJS.Namespace.define("DataExample", publicMembers);
            lstVContactDetails.winControl.itemDataSource = DataExample.itemList.dataSource;

            document.getElementById("lstVContactDetails").addEventListener("iteminvoked", this.itemInvoked, false);
            tbContactName.onkeyup = function (args) {
                var filteredList = dataList.createFiltered(function (listItem) {
                    return (listItem.firstname.toUpperCase().indexOf(tbContactName.value.toUpperCase()) >= 0)

                });
                var publicMembers =
                {
                    itemList: filteredList
                };
                WinJS.Namespace.define("DataExample", publicMembers);

                lstVContactDetails.winControl.itemDataSource = DataExample.itemList.dataSource;
            };

            document.getElementById("lstVContactDetails").addEventListener("contextmenu", this.contactListHandler, false);

        },
        itemInvoked: function (eventInfo) {
            eventInfo.detail.itemPromise.then(function (invokedItem) {
                WinJS.Navigation.navigate("/pages/DetailPage/DetailPage.html", invokedItem.data);
            });

        },
        contactListHandler: function (e) {
            var menu = new Windows.UI.Popups.PopupMenu();
            menu.commands.append(new Windows.UI.Popups.UICommand("Delete", onDelete));
            menu.commands.append(new Windows.UI.Popups.UICommand("Edit", onEdit));
            menu.showAsync({ x: e.pageX, y: e.pageY });

        }

    });

})();
