﻿var index;
// For an introduction to the Page Control template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232511
(function () {
    "use strict";

    WinJS.UI.Pages.define("/pages/EditPage/EditPage.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {
            // TODO: Initialize the page here.
            index = options;
            firstName.innerText = peopleData.peopleArray[index].firstname;
            lastName.innerText = peopleData.peopleArray[index].lastname;
            img.src = peopleData.peopleArray[index].pImg;
            phoneNo.innerText = peopleData.peopleArray[index].mobileNo;
            emailID.innerText = peopleData.peopleArray[index].email;

            document.getElementById("update").addEventListener("click", this.update_event, false);
            
        },

        unload: function () {
            // TODO: Respond to navigations away from this page.
        },

        update_event : function(e)
        {
                        
                
            peopleData.peopleArray[index].firstname = firstName.value;
            peopleData.peopleArray[index].lastname = lastName.value;
            peopleData.peopleArray[index].mobileNo = phoneNo.value;
            peopleData.peopleArray[index].email = emailID.value;
            var msg = Windows.UI.Popups.MessageDialog("Contact details updated");
            msg.showAsync().done(function () {
                WinJS.Navigation.navigate('/pages/home/home.html');
            });

        },
         
        updateLayout: function (element, viewState, lastViewState) {
           

            // TODO: Respond to changes in viewState.
        }
    });
})();
