﻿

(function () {
    "use strict";

    WinJS.UI.Pages.define("/pages/home/home.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {
            // TODO: Initialize the page here.
            document.getElementById("submit").addEventListener("click", this.submitclick, false);

        },

        submitclick: function (e) {
            var object1 = {
                uname: aname.value, ucontact: acontact.value, uemail: aemail.value, uwebsite: awebsite.value,
                uobj: aobj.textContent, uquali:aquali.textContent, upl: apl.value, uol: aol.value,uexp:aexp.textContent, uworkexpyrs: aworkexpyrs.value,
                uworkexpmnths: aworkexpmnths.value, udate: adate.winControl.current, unationality: anationality.value, ustatus: astatus[0].checked,
                ul: alang.value, ugender: agender[0].checked
            };
           

            if (aname.value == "" || acontact.value == "" || aemail.value == "" || aobj.textContent == "" || aquali.textContent== "" || apl.value == "" || aol.value == "" || aexp.textContent =="" || aworkexpyrs.value == "" || aworkexpmnths.value == "" || anationality.value == "" || alang.value=="") {

                var msg = new Windows.UI.Popups.MessageDialog("Please complete the form!!");
                msg.showAsync();

            }

            else {
                WinJS.Navigation.navigate("/pages/resume/resume.html", object1);
            }
        }
        
    });
})();
