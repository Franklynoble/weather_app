﻿function dateFormat(date, format) {
    // Calculate date parts and replace instances in format string accordingly
    format = format.replace("DD", (date.getDate() < 10 ? '0' : '') + date.getDate()); 
    format = format.replace("MM", (date.getMonth() < 9 ? '0' : '') + (date.getMonth() + 1)); 
    format = format.replace("YYYY", date.getFullYear());
    return format;
}
// For an introduction to the Page Control template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232511
(function () {
    "use strict";

    WinJS.UI.Pages.define("/pages/resume/resume.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {
            // TODO: Initialize the page here.
            aname.innerText = options.uname;
            acontact.innerText = options.ucontact;
            aemail.innerText = options.uemail + "@" + options.uwebsite + ".com";
            aobj.innerText = options.uobj;
            aquali.innerText = options.uquali;
            apl.innerText = options.upl;
            aol.innerText = options.uol;
            aexp.innerText = options.uexp;
            aworkexpmnths.innerText = options.uworkexpmnths;
            aworkexpyrs.innerText = options.uworkexpyrs;
            var dt = new Date(options.udate);
            adate.innerText = dateFormat(dt, "DD-MM-YYYY");
            anationality.innerText = options.unationality;
            asign.innerText = "( " + options.uname + " )";
            astatus.innerText = ((options.ustatus) ? "Single" : "Married");
            agender.innerText = ((options.ugender) ? "Male" : "Female");
            alang.innerText = options.ul;
        },

        unload: function () {
            // TODO: Respond to navigations away from this page.
        },

        updateLayout: function (element, viewState, lastViewState) {
            /// <param name="element" domElement="true" />

            // TODO: Respond to changes in viewState.
        }
    });
})();
