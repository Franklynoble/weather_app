﻿// For an introduction to the Page Control template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232511
(function () {
    "use strict";

    WinJS.UI.Pages.define("/pages/stories/story.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {
            // TODO: Initialize the page here.
            
           
                document.getElementById("title").innerText = options.title;
                document.getElementById("story").textContent = options.story;
                var sp = Windows.ApplicationModel.DataTransfer.DataTransferManager.getForCurrentView();
                sp.ondatarequested = function (e) {
                    e.request.data.properties.title = document.getElementById("title").innerText;
                    e.request.data.setText(document.getElementById("story").textContent);
                
            }
        },

        unload: function () {
            // TODO: Respond to navigations away from this page.
        },

        updateLayout: function (element, viewState, lastViewState) {
            /// <param name="element" domElement="true" />

            // TODO: Respond to changes in viewState.
        }
    });
})();
