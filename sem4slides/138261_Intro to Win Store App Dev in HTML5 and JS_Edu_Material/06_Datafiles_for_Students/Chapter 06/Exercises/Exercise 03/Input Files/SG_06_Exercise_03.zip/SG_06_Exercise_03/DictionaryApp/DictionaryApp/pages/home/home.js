﻿var wordMeaning = [
    { word: "Abrogation", meaning: "To cancel or revoke formally or officially." },
    { word: "Barter", meaning: "To trade by exchange of commodities rather than by the use of money." },
    { word: "Brittleness", meaning: "Breaking readily with a comparatively smooth fracture, as glass." },
    { word: "Bungler", meaning: "To perform or work clumsily or inadequately." },
    { word: "Caprice", meaning: "A tendency to change one's mind without apparent or adequate motive." },
    { word: "Class", meaning: "A number of persons or things regarded as forming a group by reason of common attributes, characteristics, qualities, or traits." },
    { word: "Courtesy", meaning: "Polite behavior." },
    { word: "Deity", meaning: "Divine character or nature, especially that of the Supreme Being." },
    { word: "Dupe", meaning: "A person who is easily deceived or fooled." },
    { word: "Fear", meaning: "A distressing emotion aroused by impending danger, evil, or pain, whether the threat is real or imagined." }
   
];

(function () {
    "use strict";

    WinJS.UI.Pages.define("/pages/home/home.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {
            // TODO: Initialize the page here.


        }
    });

})();
