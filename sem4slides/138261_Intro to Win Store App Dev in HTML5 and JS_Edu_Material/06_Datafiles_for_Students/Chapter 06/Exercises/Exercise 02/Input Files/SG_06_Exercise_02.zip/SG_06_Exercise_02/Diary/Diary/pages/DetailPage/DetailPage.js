﻿var Event = WinJS.Class.define(function (eventTitle, eventDate, eventDescription, eventLocation) {
    this.eventTitle = eventTitle;
    this.eventDate = eventDate;
    this.eventDescription = eventDescription;
    this.eventLocation = eventLocation;
},
    {
        eventTitle: "", eventDate: "", eventLocation: "", eventDescription: ""
    },
    null
   );

WinJS.Namespace.define("nsEvents",
               {
                   Events: Event
               });

var eventsArray = new Array();

WinJS.Namespace.define("nsEventsArray",
               {
                   EventsArray: eventsArray
               });
// For an introduction to the Page Control template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232511
(function () {
    "use strict";

    WinJS.UI.Pages.define("/pages/DetailPage/DetailPage.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {
            // TODO: Initialize the page here.

            p1.innerText = "Welcome " + options;
           
        },

        unload: function () {
            // TODO: Respond to navigations away from this page.
        },

        updateLayout: function (element, viewState, lastViewState) {
            /// <param name="element" domElement="true" />

            // TODO: Respond to changes in viewState.
        }
    });
})();
