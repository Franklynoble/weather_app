﻿var dataList;
var Person = WinJS.Binding.define({
    firstname: "",
    lastname: "",
    pImg: "",
    mobileNo: "",
    email: "",
});
WinJS.Namespace.define("nsPersonClass", { Pers: Person });
var info = new Array();


var people = [
       new nsPersonClass.Pers({ firstname: "Bob", lastname: "Patrick", pImg: "ms-appx:///images/1.jpg", mobileNo: "9852224517", email: "bob989@yahoo.com" }),
       new nsPersonClass.Pers({ firstname: "Sally", lastname: "John", pImg: "ms-appx:///images/2.jpg", mobileNo: "9987234121", email: "sally.99@hotmail.com" }),
       new nsPersonClass.Pers({ firstname: "Marry", lastname: "Smith", pImg: "ms-appx:///images/3.jpg", mobileNo: "7867882312", email: "marry_Smith@yahoo.com" }),
       new nsPersonClass.Pers({ firstname: "David", lastname: "Peter", pImg: "ms-appx:///images/4.jpg", mobileNo: "9999881278", email: "peter002@gmail.com" }),
       new nsPersonClass.Pers({ firstname: "Steve", lastname: "Paul", pImg: "ms-appx:///images/5.jpg", mobileNo: "9876564689", email: "steve.paul@yahoo.com" }),
       new nsPersonClass.Pers({ firstname: "Allen", lastname: "Jessie", pImg: "ms-appx:///images/6.jpg", mobileNo: "9544561298", email: "allen1990@yahoo.com" }),
       new nsPersonClass.Pers({ firstname: "Genelia", lastname: "Joseph", pImg: "ms-appx:///images/7.jpg", mobileNo: "9544561298", email: "Gennie@hotmail.com" }),


];
var publicPeopleArray =
{
    peopleArray: people
};
WinJS.Namespace.define("peopleData", publicPeopleArray);


// For an introduction to the Navigation template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232506
(function () {
    "use strict";

    WinJS.Binding.optimizeBindingReferences = true;

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;
    var nav = WinJS.Navigation;

    app.addEventListener("activated", function (args) {
        WinJS.Application.sessionState.sessionRestored = false;
        if (args.detail.kind === activation.ActivationKind.launch) {
            
            if (args.detail.previousExecutionState !== activation.ApplicationExecutionState.terminated) {
                // TODO: This application has been newly launched. Initialize
                // your application here.
            } else {
                // TODO: This application has been reactivated from suspension.
                // Restore application state here.

                peopleData.peopleArray = new Array();
                for (var i = 0; i < Windows.Storage.ApplicationData.current.localSettings.values["LastIndex"]; i++) {

                    var tempContact = Windows.Storage.ApplicationData.current.localSettings.values[i];
                    peopleData.peopleArray.push(new nsPersonClass.Pers({ firstname: tempContact.firstname, lastname: tempContact.lastname, pImg: tempContact.pImg, mobileNo: tempContact.mobileNo, email: tempContact.email }));

                }
            }

            WinJS.Application.sessionState.previousExecutionState =
               args.detail.previousExecutionState;


            if (app.sessionState.history) {
                nav.history = app.sessionState.history;
            }
            args.setPromise(WinJS.UI.processAll().then(function () {
                if (nav.location) {
                    nav.history.current.initialPlaceholder = true;
                    return nav.navigate(nav.location, nav.state);
                } else {
                    return nav.navigate(Application.navigator.home);
                }
            }));
        }
    });
    app.onsettings = function (eventInfo) {
        eventInfo.detail.applicationcommands = {
            "settingsDiv": { title: "Help", href: "/pages/Help/Help.html" }
        };
        WinJS.UI.SettingsFlyout.populateSettings(eventInfo);
    };

    app.oncheckpoint = function (args) {
        // TODO: This application is about to be suspended. Save any state
        // that needs to persist across suspensions here. If you need to 
        // complete an asynchronous operation before your application is 
        // suspended, call args.setPromise().
        app.sessionState.history = nav.history;
        
        var firstName = document.getElementById("firstName");
        if (firstName) {
            WinJS.Application.sessionState.firstName = (firstName.value == undefined)? firstName.innerText : firstName.value;
        }

        var lastName = document.getElementById("lastName");
        if (lastName) {
            WinJS.Application.sessionState.lastName = (lastName.value == undefined) ? lastName.innerText : lastName.value;
        }

        var img = document.getElementById("img");
        if (img) {
            WinJS.Application.sessionState.img = img.src;
        }
        var phoneNo = document.getElementById("phoneNo");
        if (phoneNo) {
            WinJS.Application.sessionState.phoneNo = (phoneNo.value == undefined) ? phoneNo.innerText : phoneNo.value;
        }
        var emailID = document.getElementById("emailID");
        if (emailID) {
            WinJS.Application.sessionState.emailID = (emailID.value == undefined) ? emailID.innerText : emailID.value;
        }

        
      
        

        var composite = new Windows.Storage.ApplicationDataCompositeValue();

        for (var i = 0; i < peopleData.peopleArray.length; i++) {
            composite["firstname"] = peopleData.peopleArray[i].firstname;
            composite["lastname"] = peopleData.peopleArray[i].lastname;
            composite["pImg"] = peopleData.peopleArray[i].pImg;
            composite["mobileNo"] = peopleData.peopleArray[i].mobileNo;
            composite["email"] = peopleData.peopleArray[i].email;
            Windows.Storage.ApplicationData.current.localSettings.values[i] = composite;
            Windows.Storage.ApplicationData.current.localSettings.values["LastIndex"] = i + 1;
        }
    };


    

    app.start();
})();
