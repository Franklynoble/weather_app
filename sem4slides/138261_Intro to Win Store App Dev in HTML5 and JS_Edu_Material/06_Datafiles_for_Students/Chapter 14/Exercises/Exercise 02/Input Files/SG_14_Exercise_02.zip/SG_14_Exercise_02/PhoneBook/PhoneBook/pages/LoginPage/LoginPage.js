﻿
function validateUser(targetName, Message, Caption) {

    var credentialPickerResults;
    var credentialPickerOptions = new Windows.Security.Credentials.UI.CredentialPickerOptions();
    credentialPickerOptions.targetName = targetName;
    credentialPickerOptions.caption = Caption;
    credentialPickerOptions.message = Message;
    credentialPickerOptions.authenticationProtocol = Windows.Security.Credentials.UI.AuthenticationProtocol.basic;
    credentialPickerOptions.alwaysDisplayDialog = false;
    var credentialPicker = Windows.Security.Credentials.UI.CredentialPicker;

    credentialPicker.pickAsync(credentialPickerOptions).then(function (results) {
        if (results.credential != null) {
            var localSettings = Windows.Storage.ApplicationData.current.localSettings;
            if (results.credentialUserName == localSettings.values["userName"] && results.credentialPassword == localSettings.values["password"]) {
                WinJS.Navigation.navigate("/pages/home/home.html");
            }
            else {
                validateUser(targetName, "Inavlid Username or Password. Please try again.", Caption);
            }
        }
    });



}
// For an introduction to the Page Control template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232511
(function () {
    "use strict";

    WinJS.UI.Pages.define("/pages/LoginPage/LoginPage.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {
            // TODO: Initialize the page here.


            var localSettings = Windows.Storage.ApplicationData.current.localSettings;
            //check if the user is already register
            if (localSettings.values["userName"] && localSettings.values["password"]) {
                //User is already registered enable the Login button.
                bttnLogin.disabled = false;
            }
            else {
                //User is not register enable the Register button.
                bttnRegister.disabled = false;
            }
            bttnLogin.onclick = function (args) {
                var targetName, Message, Caption;
                targetName = "PhoneBook App";
                Message = "Please provide your username and password, which you provided at the time of registeration.";
                Caption = "PhoneBook App";

                validateUser(targetName, Message, Caption);

            };
            bttnRegister.onclick = function (args) {
                var targetName, Message, Caption;
                targetName = "PhoneBook App";
                Message = "Please provide your username and password to register.";
                Caption = "PhoneBook App";
                var credentialPickerResults;
                var credentialPickerOptions = new Windows.Security.Credentials.UI.CredentialPickerOptions();
                credentialPickerOptions.targetName = targetName;
                credentialPickerOptions.caption = Caption;
                credentialPickerOptions.message = Message;
                credentialPickerOptions.authenticationProtocol = Windows.Security.Credentials.UI.AuthenticationProtocol.basic;
                credentialPickerOptions.alwaysDisplayDialog = false;
                var credentialPicker = Windows.Security.Credentials.UI.CredentialPicker;
                credentialPicker.pickAsync(credentialPickerOptions).then(function (results) {
                    if (results.credential != null) {
                        localSettings.values["userName"] = results.credentialUserName;
                        localSettings.values["password"] = results.credentialPassword;
                        var msg = Windows.UI.Popups.MessageDialog("User registered successfully.");
                        msg.showAsync().done(function (args) {
                            WinJS.Navigation.navigate("/pages/home/home.html");
                        });
                    }
                    else {
                        var msg = Windows.UI.Popups.MessageDialog("Registration process is cancelled successfully.");
                        msg.showAsync();
                    }
                });

            };
        },

        unload: function () {
            // TODO: Respond to navigations away from this page.
        },

        updateLayout: function (element, viewState, lastViewState) {
            /// <param name="element" domElement="true" />

            // TODO: Respond to changes in viewState.
        }
    });
})();
