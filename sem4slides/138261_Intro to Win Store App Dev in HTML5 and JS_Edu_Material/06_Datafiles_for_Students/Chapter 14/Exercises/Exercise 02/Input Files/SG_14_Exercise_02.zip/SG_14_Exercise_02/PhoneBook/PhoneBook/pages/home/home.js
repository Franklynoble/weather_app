﻿

function onEdit(eventInfo) {
    var listView = document.getElementById('lstVContactDetails').winControl;
    var selection = listView.selection.getItems().done(function (items) {

        items.forEach(function (item) {
            for (var i = 0; i < peopleData.peopleArray.length; i++) {
                if (peopleData.peopleArray[i].firstname == item.data.firstname) {
                    WinJS.Navigation.navigate("/pages/EditPage/EditPage.html", i);
                    break;
                }
            }

        });

    });
}


function onDelete() {
    var msg = Windows.UI.Popups.MessageDialog("Are you sure that you want to delete the record?");
    msg.commands.append(new Windows.UI.Popups.UICommand("Yes", function (msg) {

        var localSettings = Windows.Storage.ApplicationData.current.localSettings;
        var listView = document.getElementById('lstVContactDetails').winControl;
        var totalContactsDeleted = 0;
        var selection = listView.selection.getItems().done(function (items) {
            items.forEach(function (item) {
                for (var i = 0; i < peopleData.peopleArray.length; i++) {
                    if (peopleData.peopleArray[i].firstname == item.data.firstname) {
                        peopleData.peopleArray.splice(i, 1);
                        totalContactsDeleted++;
                        break;
                    }
                }


            });
            /*
              Code for sending Toast notification
          */
            var notifications = Windows.UI.Notifications;
            var template = notifications.ToastTemplateType.toastText01;
            var toastXml = notifications.ToastNotificationManager.getTemplateContent(template);
            var txt1 = "";
            if (totalContactsDeleted > 0)
                txt1 = toastXml.createTextNode("Totoal " + totalContactsDeleted + " contact(s) deleted successfully.");
            else
                txt1 = toastXml.createTextNode("No contacts deleted.");
            var toasttextElements = toastXml.getElementsByTagName("text");
            toasttextElements[0].appendChild(txt1);
            var toast = new notifications.ToastNotification(toastXml);
            var tf = notifications.ToastNotificationManager.createToastNotifier();
            tf.show(toast);
            /*
                End of code for sending Toast notification
            */
        });

        Windows.Storage.ApplicationData.current.clearAsync();
        for (var i = 0; i < peopleData.peopleArray.length; i++) {
            var composite = new Windows.Storage.ApplicationDataCompositeValue();
            composite["firstname"] = peopleData.peopleArray[i].firstname;
            composite["lastname"] = peopleData.peopleArray[i].lastname;
            composite["pImg"] = peopleData.peopleArray[i].pImg;
            composite["mobileNo"] = peopleData.peopleArray[i].mobileNo;
            composite["email"] = peopleData.peopleArray[i].email;

            Windows.Storage.ApplicationData.current.localSettings.values[i] = composite;
        }

        Windows.Storage.ApplicationData.current.localSettings.values["LastIndex"] = peopleData.peopleArray.length;

        localSettings.values["appDataCreated"] = true;
        showData();

    }));

    msg.commands.append(new Windows.UI.Popups.UICommand("No", function (msg) {
        lstVContactDetails.winControl.itemDataSource = null;
        showData();
    }));


    msg.showAsync();
}
function showData() {
    peopleData.peopleArray = new Array();
    var lc = Windows.Storage.ApplicationData.current.localSettings;
    for (var i = 0; i < Windows.Storage.ApplicationData.current.localSettings.values["LastIndex"]; i++) {
        if (lc.values[i])
            peopleData.peopleArray.push(new nsPersonClass.Pers({ firstname: lc.values[i].firstname, lastname: lc.values[i].lastname, pImg: lc.values[i].pImg, mobileNo: lc.values[i].mobileNo, email: lc.values[i].email }));

    }

    dataList = new WinJS.Binding.List(peopleData.peopleArray);
    dataList.sort(function (person1, person2) {
        if (person1.firstname == undefined || person2.firstname == undefined)
            return null;
        return person1.firstname.toUpperCase().localeCompare(person2.firstname.toUpperCase());
    });
    lstVContactDetails.winControl.itemDataSource = dataList.dataSource;
}

(function () {
    "use strict";

    WinJS.UI.Pages.define("/pages/home/home.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.


        ready: function (element, options) {
            // TODO: Initialize the page here.

            var localSettings = Windows.Storage.ApplicationData.current.localSettings;
            if (localSettings.values["appDataCreated"] == true) {
                showData();
            }
            else {
                for (var i = 0; i < peopleData.peopleArray.length; i++) {
                    var composite = new Windows.Storage.ApplicationDataCompositeValue();
                    composite["firstname"] = peopleData.peopleArray[i].firstname;
                    composite["lastname"] = peopleData.peopleArray[i].lastname;
                    composite["pImg"] = peopleData.peopleArray[i].pImg;
                    composite["mobileNo"] = peopleData.peopleArray[i].mobileNo;
                    composite["email"] = peopleData.peopleArray[i].email;

                    Windows.Storage.ApplicationData.current.localSettings.values[i] = composite;


                }
                Windows.Storage.ApplicationData.current.localSettings.values["LastIndex"] = peopleData.peopleArray.length;

                localSettings.values["appDataCreated"] = true;
                showData();
            }


            document.getElementById("lstVContactDetails").addEventListener("iteminvoked", this.itemInvoked, false);
            tbContactName.onkeyup = function (args) {
                var filteredList = dataList.createFiltered(function (listItem) {
                    return (listItem.firstname.toUpperCase().indexOf(tbContactName.value.toUpperCase()) >= 0)

                });
                var publicMembers =
                {
                    itemList: filteredList
                };
                WinJS.Namespace.define("DataExample", publicMembers);
                lstVContactDetails.winControl.itemDataSource = DataExample.itemList.dataSource;

            };

            document.getElementById("lstVContactDetails").addEventListener("contextmenu", this.contactListHandler, false);

        },
        itemInvoked: function (eventInfo) {
            eventInfo.detail.itemPromise.then(function (invokedItem) {
                WinJS.Navigation.navigate("/pages/DetailPage/DetailPage.html", invokedItem.data);
            });

        },
        contactListHandler: function (e) {
            var menu = new Windows.UI.Popups.PopupMenu();
            menu.commands.append(new Windows.UI.Popups.UICommand("Delete", onDelete));
            menu.commands.append(new Windows.UI.Popups.UICommand("Edit", onEdit));
            menu.showAsync({ x: e.pageX, y: e.pageY });

        }

    });

})();
