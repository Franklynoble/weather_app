﻿(function () {
    "use strict";

    WinJS.UI.Pages.define("/pages/home/home.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {
            // TODO: Initialize the page here.

            var button1 = document.getElementById("bttnRegister");
            button1.addEventListener("click", this.buttonClickHandler1, false);
        },
        buttonClickHandler1: function (eventInfo) {
            if (tbUserName.value == "" || pbPassword.value == "") {

                var strMessage = "User name or password cannot be left blank.";
                var msg = new Windows.UI.Popups.MessageDialog(strMessage);
                msg.showAsync();
            }
            else
                WinJS.Navigation.navigate("/pages/DetailPage/DetailPage.html", tbUserName.value);
        }
    });
})();
