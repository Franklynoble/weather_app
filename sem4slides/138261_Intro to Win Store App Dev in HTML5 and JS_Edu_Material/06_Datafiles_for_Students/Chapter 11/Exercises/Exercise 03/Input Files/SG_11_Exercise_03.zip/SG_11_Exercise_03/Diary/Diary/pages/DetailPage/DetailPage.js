﻿var Event = WinJS.Class.define(function (eventTitle, eventDate, eventDescription, eventLocation) {
    this.eventTitle = eventTitle;
    this.eventDate = eventDate;
    this.eventDescription = eventDescription;
    this.eventLocation = eventLocation;
},
    {
        eventTitle: "", eventDate: "", eventLocation: "", eventDescription: ""
    },
    null
   );

WinJS.Namespace.define("nsEvents",
               {
                   Events: Event
               });

var eventsArray = new Array();

WinJS.Namespace.define("nsEventsArray",
               {
                   EventsArray: eventsArray
               });
// For an introduction to the Page Control template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232511
(function () {
    "use strict";

    WinJS.UI.Pages.define("/pages/DetailPage/DetailPage.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {
            // TODO: Initialize the page here.
            var EventList = new WinJS.Binding.List(nsEventsArray.EventsArray);
            p1.innerText = "Welcome " + options;
            cmdAdd.onclick = function (args) { WinJS.Navigation.navigate("/pages/AddEvent/AddEventPage.html", options); };
            if (nsEventsArray.EventsArray.length != 0) {
                
                lstviewDiaryEvents.winControl.itemDataSource = EventList.dataSource;
                NoRecordsFoundDiv.style.visibility = "hidden";
                
            }
            else {
                NoRecordsFoundDiv.style.visibility = "visible";
            }
            var dataTransferManager = Windows.ApplicationModel.DataTransfer.DataTransferManager.getForCurrentView();
            dataTransferManager.ondatarequested = function (e) {
                if (EventList.length > 0) {
                    e.request.data.properties.title = "Events";

                    var htmlContent = "";
                    EventList.forEach(function (dataItem) {
                        htmlContent +=

                "<span><b>Title:</b> </span><span>" + dataItem.eventTitle + "</span>" +
               " <br />" +
                "<span><b>Date:</b> </span><span>" + dataItem.eventDate + "</span>" +
                "<br />" +
                "<span><b>Location:</b> </span><span>" + dataItem.eventLocation + "</span>" +
                "<br />" +
                "<span><b>Description:</b> </span>" +
                "<span>" + dataItem.eventDescription + "</span><br><br>";

                    });

                    var htmlFormat = Windows.ApplicationModel.DataTransfer.HtmlFormatHelper.createHtmlFormat(htmlContent);
                    e.request.data.setHtmlFormat(htmlFormat);
                }
               
            };
            bttnSearch.onclick = function (args) {
                if (nsEventsArray.EventsArray.length != 0) {
                    var EventList = new WinJS.Binding.List(nsEventsArray.EventsArray);
                    var filterList = EventList.createFiltered(function (diaryEvent) {
                        return (diaryEvent.eventTitle.toUpperCase().indexOf(tbEventTitle.value.toUpperCase())) >= 0;
                    });
                    lstviewDiaryEvents.winControl.itemDataSource = filterList.dataSource;
                    NoRecordsFoundDiv.style.visibility = "hidden";
                }
                else {
                    NoRecordsFoundDiv.style.visibility = "visible";
                }
            }
            cmdExport.onclick = function (args) {
                var currentState = Windows.UI.ViewManagement.ApplicationView.value;
                if (currentState === Windows.UI.ViewManagement.ApplicationViewState.snapped && !Windows.UI.ViewManagement.ApplicationView.tryUnsnap()) {
                    return;
                }
                if (nsEventsArray.EventsArray.length <= 0) {
                    var msg = new Windows.UI.Popups.MessageDialog("There are no events to export.");
                    msg.showAsync();
                    return;
                }
                var savePicker = new Windows.Storage.Pickers.FileSavePicker();
                savePicker.suggestedStartLocation = Windows.Storage.Pickers.PickerLocationId.documentsLibrary;
                savePicker.fileTypeChoices.insert("Plain Text File", [".TXT"]);
                savePicker.suggestedFileName = "DiaryEventsBackup";
                var eventsBackup = new Array();


                for (var i = 0; i < nsEventsArray.EventsArray.length; i++) {
                    if (nsEventsArray.EventsArray[i]) {
                        eventsBackup.push("Event Title: " + nsEventsArray.EventsArray[i].eventTitle);
                        eventsBackup.push("Event Date: " + nsEventsArray.EventsArray[i].eventDate);
                        eventsBackup.push("Event Location: " + nsEventsArray.EventsArray[i].eventLocation);
                        eventsBackup.push("Event Description: " + nsEventsArray.EventsArray[i].eventDescription.replace(/\n/gi, "  "));
                        eventsBackup.push("");
                        eventsBackup.push("***********************************************************************");
                        eventsBackup.push("");

                    }
                }
               savePicker.pickSaveFileAsync().then(function (file) {
                    if (file)
                        Windows.Storage.FileIO.writeLinesAsync(file, eventsBackup).done(function () {
                            var msg = Windows.UI.Popups.MessageDialog("Diary events exported successfully.");
                            msg.showAsync();
                        });
                });

            };
        },

        unload: function () {
            // TODO: Respond to navigations away from this page.
        },

        updateLayout: function (element, viewState, lastViewState) {
            /// <param name="element" domElement="true" />

            // TODO: Respond to changes in viewState.
        }
    });
})();
