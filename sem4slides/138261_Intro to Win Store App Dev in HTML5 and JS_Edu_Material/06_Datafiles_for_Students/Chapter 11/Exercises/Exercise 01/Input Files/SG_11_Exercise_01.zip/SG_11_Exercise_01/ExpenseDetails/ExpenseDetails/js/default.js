﻿var Expense = WinJS.Class.define(function (expenseDate, expenseType, expenseAmount, expenseDescription) {
    this.expenseDate = expenseDate;
    this.expenseType = expenseType;
    this.expenseAmount = expenseAmount;
    this.expenseDescription = expenseDescription;
},
    {
        expenseDate: "", expenseType: "", expenseAmount: 0.0, expenseDescription: ""
    },
    null
   );

WinJS.Namespace.define("expense",
               {
                   expenses: Expense
               });
var expenseArray = new Array();

WinJS.Namespace.define("nsExpenseArray", { expnsArray: expenseArray });

// For an introduction to the Navigation template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232506
(function ()
{
    "use strict";

    WinJS.Binding.optimizeBindingReferences = true;

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;
    var nav = WinJS.Navigation;

    app.addEventListener("activated", function (args) {
        WinJS.Application.sessionState.sessionRestored = false;

        if (args.detail.kind === activation.ActivationKind.launch) {
            if (args.detail.previousExecutionState !== activation.ApplicationExecutionState.terminated) {
                // TODO: This application has been newly launched. Initialize
                // your application here.
            } else {
                
                for (var i = 0; i < Windows.Storage.ApplicationData.current.localSettings.values["LastIndex"]; i++) {

                    var tempExpense = Windows.Storage.ApplicationData.current.localSettings.values[i];
                    nsExpenseArray.expnsArray.push(new Expense(tempExpense.ExpenseDate, tempExpense.ExpenseType, tempExpense.ExpenseAmount, tempExpense.ExpenseDescription));

                }
          

                // TODO: This application has been reactivated from suspension.
                // Restore application state here.
            }

            WinJS.Application.sessionState.previousExecutionState =
               args.detail.previousExecutionState;

            if (app.sessionState.history) {
                nav.history = app.sessionState.history;
            }
            args.setPromise(WinJS.UI.processAll().then(function () {
                if (nav.location) {
                    nav.history.current.initialPlaceholder = true;
                    return nav.navigate(nav.location, nav.state);
                } else {
                    return nav.navigate(Application.navigator.home);
                }
            }));
        }
    });

    app.oncheckpoint = function (args) {
        // TODO: This application is about to be suspended. Save any state
        // that needs to persist across suspensions here. If you need to 
        // complete an asynchronous operation before your application is 
        // suspended, call args.setPromise().
        app.sessionState.history = nav.history;

            var date = document.getElementById("dtExpense");
            if (date) {
                WinJS.Application.sessionState.dtExpense = date.winControl.current.toLocaleDateString();
            }

            var expenseType = document.getElementById("cboxExpenseType");
            if (expenseType) {
                WinJS.Application.sessionState.cboxExpenseType = expenseType.selectedIndex;
            }

            var amount = document.getElementById("tbAmount");
            if (amount) {
                WinJS.Application.sessionState.tbAmount = amount.value;
            }
            var description = document.getElementById("taDescription");
            if (description) {
                WinJS.Application.sessionState.taDescription = description.textContent;
            }

            if (!Windows.Storage.ApplicationData.current.localSettings.values["LastIndex"]) {
                Windows.Storage.ApplicationData.current.localSettings.values["LastIndex"] = 0;
            }
            var composite = new Windows.Storage.ApplicationDataCompositeValue();
            for (var i = 0; i < nsExpenseArray.expnsArray.length; i++) {
                composite["ExpenseDate"] = nsExpenseArray.expnsArray[i].expenseDate;
                composite["ExpenseType"] = nsExpenseArray.expnsArray[i].expenseType;
                composite["ExpenseAmount"] = nsExpenseArray.expnsArray[i].expenseAmount;
                composite["ExpenseDescription"] = nsExpenseArray.expnsArray[i].expenseDescription;
                Windows.Storage.ApplicationData.current.localSettings.values[i] = composite;
                Windows.Storage.ApplicationData.current.localSettings.values["LastIndex"] = i + 1;
            }
       };

    app.start();
})();
