﻿
function buttonclick0(eventInfo) {
    var button = document.getElementById("div1");
    div1.style.visibility = "hidden";

}

function buttonclick(eventInfo) {
    var button = document.getElementById("div1");
    div1.style.visibility = "visible";
    div1.innerHTML = "<p>The Sun is the solar system's star, and its chief component. Its large mass produces temperatures and densities in its core high enough to sustain nuclear fusion, which releases enormous amounts of energy.</p>";
}

function buttonclick1(eventInfo) {
    var button = document.getElementById("div1");
    div1.style.visibility = "visible";
    div1.innerHTML = "<p>Mercury is the closest planet to the Sun and the smallest planet in the solar system. Mercury has no natural satellites, and its only known geological features besides impact craters are lobed ridges or rupes.</p>";
}
function buttonclick2(eventInfo) {
    var button = document.getElementById("div1");
    div1.style.visibility = "visible";
    div1.innerHTML = "<p>Venus is close in size to Earth, and, like Earth, has a thick silicate mantle around an iron core, a substantial atmosphere and evidence of internal geological activity. However, it is much drier than Earth and its atmosphere is ninety times as dense.</p>";
}
function buttonclick3(eventInfo) {
    var button = document.getElementById("div1");
    div1.style.visibility = "visible";
    div1.innerHTML = "<p>Earth is the largest and densest of the inner planets, the only one known to have current geological activity, and is the only place in the solar system where life is known to exist. Its liquid hydrosphere is unique among the terrestrial planets.</p>";
}

function buttonclick4(eventInfo) {
    var button = document.getElementById("div1");
    div1.style.visibility = "visible";
    div1.innerHTML = "<p>Mars is smaller than Earth and Venus. It possesses an atmosphere of mostly carbon dioxide with a surface pressure of 6.1 millibars. Its surface, peppered with vast volcanoes such as Olympus Mons and rift valleys such as Valles Marineris, shows geological activity.</p>";
}
function buttonclick5(eventInfo) {
    var button = document.getElementById("div1");
    div1.style.visibility = "visible";
    div1.innerHTML = "<p>Jupiter, at 318 Earth masses, is 2.5 times the mass of all the other planets put together. It is composed largely of hydrogen and helium. Jupiter's strong internal heat creates a number of semi-permanent features in its atmosphere, such as cloud bands and the Great Red Spot.</p>";
}

function buttonclick6(eventInfo) {
    var button = document.getElementById("div1");
    div1.style.visibility = "visible";
    div1.innerHTML = "<p>Saturn, distinguished by its extensive ring system, has several similarities to Jupiter, such as its atmospheric composition and magnetosphere. Although Saturn has 60% of Jupiter's volume, it is less than a third as massive, at 95 Earth masses, making it the least dense planet in the Solar System.</p>";
}

function buttonclick7(eventInfo) {
    var button = document.getElementById("div1");
    div1.style.visibility = "visible";
    div1.innerHTML = "<p>Uranus, at 14 Earth masses, is the lightest of the outer planets. Uniquely among the planets, it orbits the Sun on its side; its axial tilt is over ninety degrees to the ecliptic. It has a much colder core than the other gas giants, and radiates very little heat into space.</p>";
}

function buttonclick8(eventInfo) {
    var button = document.getElementById("div1");
    div1.style.visibility = "visible";
    div1.innerHTML = "</p>Neptune , though slightly smaller than Uranus, is more massive and therefore more dense. It radiates more internal heat, but not as much as Jupiter or Saturn. Neptune has 13 known satellites. The largest, Triton, is geologically active, with geysers of liquid nitrogen.</p>";
}

function buttonclick9(eventInfo) {
    var button = document.getElementById("div1");
    div1.style.visibility = "visible";
    div1.innerHTML = "<p>Asteroids are small solar system bodies composed mainly of refractory rocky and metallic minerals, with some ice. The asteroid belt occupies the orbit between Mars and Jupiter, between 2.3 and 3.3 AU from the Sun.</p>";
}

function buttonclick10(eventInfo) {
    var button = document.getElementById("div1");
    div1.style.visibility = "visible";
    div1.innerHTML = "<p>Comets are small Solar System bodies, typically only a few kilometres across, composed largely of volatile ices. They have highly eccentric orbits, generally a perihelion within the orbits of the inner planets and an aphelion far beyond Pluto.</p>";
}

function buttonclick11(eventInfo) {
    var button = document.getElementById("div1");
    div1.style.visibility = "visible";
    div1.innerHTML = "<p>The Moon is the only natural satellite of the Earth, and the fifth largest satellite in the solar system. It is the largest natural satellite of a planet in the solar system relative to the size of its primary, having 27% the diameter and 60% the density of Earth.</p>";
}

document.getElementById("body1").addEventListener("click", buttonclick0, true);

document.getElementById("sun").addEventListener("click", buttonclick, true);

document.getElementById("mer").addEventListener("click", buttonclick1, true);

document.getElementById("ven").addEventListener("click", buttonclick2, true);

document.getElementById("ear").addEventListener("click", buttonclick3, true);

document.getElementById("mar").addEventListener("click", buttonclick4, true);

document.getElementById("jup").addEventListener("click", buttonclick5, true);

document.getElementById("sat").addEventListener("click", buttonclick6, true);

document.getElementById("ura").addEventListener("click", buttonclick7, true);

document.getElementById("nep").addEventListener("click", buttonclick8, true);

document.getElementById("ast").addEventListener("click", buttonclick9, true);

document.getElementById("com").addEventListener("click", buttonclick10, true);

document.getElementById("moo").addEventListener("click", buttonclick11, true);
