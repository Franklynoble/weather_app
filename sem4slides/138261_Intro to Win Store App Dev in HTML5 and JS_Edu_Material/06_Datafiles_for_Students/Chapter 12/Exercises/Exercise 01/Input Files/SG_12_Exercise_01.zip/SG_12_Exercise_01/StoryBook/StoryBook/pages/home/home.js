﻿
var storyList;
(function () {
    "use strict";
    WinJS.Binding.optimizeBindingReferences = true;
    
    var stories = new Array();

    WinJS.UI.Pages.define("/pages/home/home.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.

        ready: function (element, options) {
            // TODO: Initialize the page here.

            storyList = new WinJS.Binding.List(nsStoryArray.stryArray);

            storieslst.winControl.itemDataSource = storyList.dataSource;

            var addCommand = document.getElementById("cmdAdd");
            addCommand.addEventListener("click", this.addCommandClickHandler, false);
            document.getElementById("storieslst").addEventListener("iteminvoked", this.itemInvoked, false);
                   
            if (nsStoryArray.stryArray.length === 0)
                        noStory.style.visibility = "visible";
                    else
                        noStory.style.visibility = "hidden";

                   
           },
        addCommandClickHandler: function (eventInfo) {
     
            WinJS.Navigation.navigate("/pages/addStory/addStory.html");
        },
        itemInvoked: function (eventInfo) {
            eventInfo.detail.itemPromise.then(function (invokedItem) {
                WinJS.Navigation.navigate("/pages/stories/story.html", invokedItem.data);
            });

        }
        
    });


})();
