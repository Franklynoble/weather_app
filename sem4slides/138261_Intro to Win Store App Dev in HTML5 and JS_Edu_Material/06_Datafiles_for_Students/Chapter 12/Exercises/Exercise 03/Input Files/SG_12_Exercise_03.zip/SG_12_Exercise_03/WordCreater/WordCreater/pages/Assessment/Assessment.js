﻿var letterArray = new Array(
"A",
"B",
"C",
"D",
"E",
"F",
"G",
"H",
"I",
"J",
"K",
"L",
"M",
"N",
"O",
"P",
"Q",
"R",
"S",
"T",
"U",
"V",
"W",
"X",
"Y",
"Z"

);

var currentLetterIndex = -1;

function generateQuestion() {
    var randomNumber = Math.floor((Math.random() * 26));
    //Ensure that the new random number is not exactly the same used for last question
    while (randomNumber == currentLetterIndex)
        randomNumber = Math.floor((Math.random() * 26));
    currentLetterIndex = randomNumber;
    letterVoice.src = "/sounds/" + letterArray[currentLetterIndex] + ".mp3";
}


// For an introduction to the Page Control template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232511
(function () {
    "use strict";

    WinJS.UI.Pages.define("/pages/Assessment/Assessment.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {
            // TODO: Initialize the page here.

        WinJS.UI.executeAnimation(lettercontainer, 
         {
            property: "opacity",
            delay: 0,
            duration: 1000,
            timing: "linear",
            from: 0,
            to: 1
         
         });

        WinJS.UI.executeAnimation(imgResuult,
        {
            property: "width",
            delay: 0,
            duration: 1000,
            timing: "ease",
            from: "0px",
            to: "420px"
        });


        bttnStart.onclick = function (args)
            {
                for (var i = 0; i <= 26; ++i) {
                    var bttn = document.getElementById("bttn" + i);
                    if (bttn)
                        bttn.onclick = function (args) {
                            if (this.innerText == letterArray[currentLetterIndex]) {
                                imgResuult.src = "/images/thumbs up.png";
                                generateQuestion();
                                WinJS.UI.executeAnimation(imgResuult,
                                {
                                    property: "width",
                                    delay: 0,
                                    duration: 1000,
                                    timing: "ease",
                                    from: "0px",
                                    to: "420px"
                                }

                            );

                            }
                            else {
                                imgResuult.src = "/images/thumbs down.jpg";
                                letterVoice.play();

                                WinJS.UI.executeAnimation(imgResuult,
                                {
                                    property: "width",
                                    delay: 0,
                                    duration: 1000,
                                    timing: "ease",
                                    from: "0px",
                                    to: "420px"
                                }

                            );

                            }

                        };
                }
                bttnStart.style.visibility = "hidden";
                bttnReplayAudio.style.visibility = "visible";
                generateQuestion();

            }

            bttnInstruction.onclick = function (args) {
                
                var dialog = Windows.UI.Popups.MessageDialog("Listen to the audio, and then click the appropriate letter.");
                dialog.showAsync();


            }
            
            bttnReplayAudio.onclick = function (args) {
                letterVoice.play();
            };
          
        },
                                                   

        unload: function () {
            // TODO: Respond to navigations away from this page.
        },

        updateLayout: function (element, viewState, lastViewState) {
        

            // TODO: Respond to changes in viewState.
        }
    });
})();
